##
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
##
import logging
import time
import io
import json

from typing import List

from msrest.authentication import Authentication
from azure.quantum.client import JobsClient
from azure.quantum.client.models import JobDetails
from azure.quantum.storage import download_blob
from azure.storage.blob import BlobServiceClient, ContainerClient, BlobSasPermissions, generate_blob_sas, generate_container_sas

__all__ = ['Job']

logger = logging.getLogger(__name__)

class Job:
    def __init__(self, workspace, job_details: JobDetails):
      self.workspace = workspace
      self.details = job_details
      self.id = job_details.id
      self.results = None


    def refresh(self):
        """Refreshes the Job's details by querying the workspace.
        """
        self.details = self.workspace.get_job(self.id).details

    def has_completed(self):
        return (
            self.details.status == "Succeeded" or
            self.details.status == "Failed" or
            self.details.status == "Cancelled"
        )

    def wait_until_completed(self):
        """Keeps refreshing the Job's details until it reaches a finished status.
        """
        self.refresh()
        w=False
        while not self.has_completed():
            logger.debug(f"Waiting for job {self.id}, it is in status '{self.details.status}'")
            print('.', end='', flush=True)
            w=True
            # TODO: #12341
            time.sleep(.2)
            self.refresh()

        if w:
            print("")

    def get_results(self):
        if not self.results is None:
            return self.results

        if not self.has_completed():
            self.wait_until_completed()

        if not self.details.status == "Succeeded":
            raise RuntimeError(f"Cannot retrieve results as job execution failed (status: {self.details.status})")

        payload = download_blob(self.details.container_uri, "rawOutputData")
        result = json.loads(payload.decode('utf8'))
        return result
