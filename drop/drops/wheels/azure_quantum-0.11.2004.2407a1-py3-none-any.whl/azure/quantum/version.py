# Auto-generated file, do not edit.
##
# version.py: Specifies the version of the azure.quantum package.
##
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
##
__version__ = "0.11.2004.2407a1"
