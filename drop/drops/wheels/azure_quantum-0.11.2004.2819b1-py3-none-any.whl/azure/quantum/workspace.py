##
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
##
import json
import logging
import msal
import os
import sys
import time
import requests

from pathlib import Path
from typing import List

from msrest.authentication import Authentication, BasicTokenAuthentication
from azure.quantum.client import JobsClient
from azure.quantum import Job

logger = logging.getLogger(__name__)

__all__ = ['Workspace']

## Environment variables:
BASE_URL    = os.environ['AZURE_QUANTUM_BASEURL'] if 'AZURE_QUANTUM_BASEURL' in os.environ else "https://app-jobscheduler-prod.azurewebsites.net/"
TOKEN_CACHE = os.environ['AZURE_QUANTUM_TOKEN_CACHE'] if 'AZURE_QUANTUM_TOKEN_CACHE' in os.environ else os.path.join(Path.home(), ".azure-quantum", "aad.bin")

class TokenCacheWrapper:
    def __init__(self):
        self.cache_path  = TOKEN_CACHE
        self.initialize_cache()

    def initialize_cache(self):
        logger.debug(f"Using path '{self.cache_path}' for AAD token cache")

        self.token_cache = msal.SerializableTokenCache()
        if os.path.exists(self.cache_path):
            self.token_cache.deserialize(open(self.cache_path, "r").read())

    def write_out_cache(self):
        logger.debug(f"Updating AAD token cache at '{self.cache_path}'")

        cache_folder = os.path.dirname(self.cache_path)
        if not os.path.isdir(cache_folder):
            os.makedirs(cache_folder)

        open(self.cache_path, "w").write(self.token_cache.serialize())

class MsalWrapper:
    def __init__(self, subscription_id : str, refresh : bool):
        self.subscription_id     = subscription_id
        self.refresh             = refresh
        self.client_id           = "84ba0947-6c53-4dd2-9ca9-b3694761521b" # Microsoft Quantum Development Kit
        self.scopes              = [ "https://quantum.microsoft.com/Jobs.ReadWrite" ]
        self.token_cache_wrapper = TokenCacheWrapper()
        self.app                 = None

    def get_tenant_authorization_uri(self):
        try:
            uri = f"https://management.azure.com/subscriptions/{self.subscription_id}?api-version=2018-01-01"
            response = requests.get(uri)

            # This gnarly piece of code is how we get the guest tenant authority associated with the subscription.
            # We make a unauthenticated request to ARM and extract the tenant authority from the WWW-Authenticate header in the response.
            # The header is of the form - Bearer authoritization_uri=https://login.microsoftonline.com/tenantId, key1=value1 
            authHeader = response.headers["WWW-Authenticate"]
            logger.debug (f"got the following auth header from the management endpoint: {authHeader}")

            trimmedAuthHeader = authHeader[len("Bearer "):]                                  # trim the leading 'Bearer '
            trimmedAuthHeaderParts = trimmedAuthHeader.split(",")                            # get the various k=v parts
            keyValuePairs = dict(map(lambda s: tuple(s.split("=")), trimmedAuthHeaderParts)) # make the parts into a dictionary
            quotedTenantUri = keyValuePairs["authorization_uri"]                             # get the value of the 'authorization_uri' key
            tenantUri = quotedTenantUri[1:-1]                                                # strip it of surrounding quotes

            logger.debug (f"got the following tenantUri from the authHeader: {tenantUri}")

            return tenantUri
        except Exception as e:
            logger.debug(f"Failed to get tenant authority for subscription: {e}")
            return None

    def get_app(self):
        if not self.app:
            authority = self.get_tenant_authorization_uri()
            if(authority == None):
                raise ValueError(f"Failed to get tenant authority for subscription")

            try:
                self.app = msal.PublicClientApplication(
                    self.client_id,
                    authority   = authority,
                    token_cache = self.token_cache_wrapper.token_cache)
                logger.debug (f"Created a new app with the authority: {authority}")
            except Exception as e:
                 raise ValueError(f"Failed to create PublicClientApplication with tenant authority : {e}")
        return self.app

    def clear_accounts(self):
        accounts = self.get_app().get_accounts()
        for account in accounts:
            self.get_app().remove_account(account)

    def get_token_from_device_flow(self):
        # Clear accounts before doing device flow to make sure that we are left with a single account after the user completes the device flow.
        # We use that account is subsequent silent token acquisitions.
        self.clear_accounts ()

        flow = self.get_app().initiate_device_flow(scopes=self.scopes)
        if "user_code" not in flow:
            raise ValueError("Fail to create device flow. Err: %s" % json.dumps(flow, indent=4))

        # Print a message for users to login via browser
        print(flow["message"])
        sys.stdout.flush()  # Some terminal needs this to ensure the message is shown

        result = self.get_app().acquire_token_by_device_flow(flow)  # Block until user has logged in and we're ready to continue:

        return result

    def try_get_token_silently(self):
        def try_get_account_from_app(app):
            accounts = app.get_accounts()
            if len(accounts) > 0:
                return accounts[0]
            else:
                return None

        account = try_get_account_from_app(self.get_app())

        if not account:
            return None

        # extract the tenant id from the home_account_id. The home_account_id is of the form "<oid>.<tenantId>"
        if "home_account_id" not in account:
            logger.debug("No home_account_id in account")
        
        tid = None
        account_parts = account["home_account_id"].split(".")
        if len(account_parts) < 2:
            logger.debug("No tenantId in account")
        else:
            tid = account_parts[1]

        logger.info(f"Account(s) exists in aad token cache. Getting token for (userName: {account['username']}, tenantId: {tid})")

        return self.get_app().acquire_token_silent(self.scopes, account)

    def acquire_auth_token(self):
        """Returns an AAD token, either from a local cache or from AAD.

        It will first try to retrieve the token from a local cache
        (the location of the cache can be specified via the AZURE_QUANTUM_TOKEN_CACHE environent variable).
        If it the cache is empty or expired, then it uses the device token flow from MSAL (https://github.com/AzureAD/microsoft-authentication-library-for-python)
        to acquire the token from AAD.

        Once a token is received, it is inspected to see if it is a token for an MSA account.
        If so, the guest tenant id for that account is acquired, and a token is reaquired with that authority.

        If successful, it stores the acquired token in the cache for future calls.

        :param refresh:
            if true, by-passes the cache and fetches a fresh token from AAD.
        """
        result = None

        if self.refresh:
            logger.debug("Refresh forced. Skipping getting token from cache...")
            self.clear_accounts()
        else:
            logger.debug("Trying to get token from cache...")
            result = self.try_get_token_silently ()

        if not result:
            logger.debug("...and trying to get a token from the device flow...")
            result = self.get_token_from_device_flow ()
            logger.debug(f"...device flow returned: {result}")

        # At this point, there should be an access token; raise otherwsie:
        if result and ("access_token" in result):
            logger.info("AAD token acquired successfully")
            logger.debug(f"Token:\n{result['access_token']}")

            # Store token back in cache:
            self.token_cache_wrapper.write_out_cache ()
            return result
        else:
            raise ValueError("Failed to acquire AAD token.")

class Workspace:
    # TODO: AB#1283
    # TODO: AB#1284
    credentials = None

    def __init__(self, subscription_id: str, resource_group: str, name:str, storage: str):
        self.name = name
        self.resource_group = resource_group
        self.subscription_id = subscription_id
        self.storage = storage

    def _create_client(self) -> JobsClient:
        auth = self.login()
        return JobsClient(auth, self.subscription_id, self.resource_group, self.name, BASE_URL)

    def submit_job(self, job: Job) -> Job:
        # TODO: AB#1283
        client = self._create_client()
        details = client.put_job(job.details.id, job.details)
        return Job(self, details)

    def cancel_job(self, job: Job) -> Job:
        # TODO: AB#1283
        client = self._create_client()
        details = client.delete_job(job.details.id)
        return Job(self, details)

    def get_job(self, job_id: str) -> Job:
        """Returns the job corresponding to the given id."""
        client = self._create_client()
        details = client.get_job(job_id)
        return Job(self, details)

    def list_jobs(self) -> List[Job]:
        # TODO: AB#1282
        # TODO: AB#1283
        client = self._create_client()
        jobs = client.list_jobs()

        result = []
        for j in jobs:
            result.append(Job(self, j))

        return result

    def login(self, refresh:bool=False) -> Authentication:
        """Creates user credentials to authenticate with Azure Quantum

        It will first try to read the credentials from a secure local cache
        (the location of the cache can be specified via the AZURE_QUANTUM_TOKEN_CACHE environent variable).
        If it the cache is empty or expired, then it uses the device token flow from MSAL (https://github.com/AzureAD/microsoft-authentication-library-for-python)
        to acquire a token from AAD.

        If successful, it stores the acquired token in the cache for future calls.

        :param refresh:
            if true, by-passes the cache and fetches a fresh token from AAD.

        :returns:
            the user credentials to authenticate with Azure Quantum
        """
        if refresh or (self.credentials is None):
            msal_wrapper = MsalWrapper (self.subscription_id, refresh=refresh)
            auth_token = msal_wrapper.acquire_auth_token()
            self.credentials = BasicTokenAuthentication(auth_token)

        return self.credentials